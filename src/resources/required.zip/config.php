<?php
	$GLOBALS['RMI_ADDRESS'] = "localhost:8080";
?>
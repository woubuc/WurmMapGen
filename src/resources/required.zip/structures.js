function getStructures() {
	var structureBorders = [];
	return structureBorders;
}
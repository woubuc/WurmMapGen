function getGuardTowerBorders() {
	var guardTowerBorders = [];
	return guardTowerBorders;
}

function getGuardTowers() {
	var guardTower = [];
	return guardTower;
}
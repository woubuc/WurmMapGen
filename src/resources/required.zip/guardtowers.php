<?php
	require 'config.php';

	function sendCommand($cmd) {
		$lines = file('http://'.$GLOBALS['RMI_ADDRESS'].'/'.$cmd);
		foreach ($lines as &$line) {
			$line = trim($line);
		}
		if (isset($lines[0]) && $lines[0] == "") {
			return array();
		}
		return $lines;
	}

	function parseArray($array, $explode = true, $nameKey = false) {
		if ($explode) {
			foreach ($array as $k => $v) {
				if ($v == "") {
					unset($array[$k]);
					continue;
				}
				$tmp = explode("=", $v);
				if ($nameKey) {
                			$new[$tmp[0]] = $tmp[1];
            			} else {
                			$array[$k] = array($tmp[0], $tmp[1]);;
            			}
        		}
        		if ($nameKey) {
            			return $new;
        		}
    		}
    		return $array;
	}

	function get_string_between($string, $start, $end) {
		$string = ' ' . $string;
		$ini = strpos($string, $start);
		if ($ini == 0) return '';
		$ini += strlen($start);
		$len = strpos($string, $end, $ini) - $ini;
		return substr($string, $ini, $len);
	}

	function getAllGuardTowers() {
		$guardTowers = parseArray(sendCommand("getAllGuardTowers"));
		foreach ($guardTowers as &$guardTower) {
			$guardTower[1] = explode(",", get_string_between($guardTower[1], "[", "]"));
		}
		return $guardTowers;
	}
?>
function getGuardTowerBorders() {
	var guardTowerBorders = [];
	<?php
		$gts = getAllGuardTowers();
		foreach ($gts as $gt) {
		echo("\tguardTowerBorders.push(L.polygon([xy(".($gt[1][0] - 50).",".($gt[1][1] - 50).
		"),xy(".($gt[1][0] + 51).",".($gt[1][1] - 50).
		"),xy(".($gt[1][0] + 51).",".($gt[1][1] + 51).
		"),xy(".($gt[1][0] - 50).",".($gt[1][1] + 51).
		")], {color:'red',fillOpacity:0.1,weight:1}));\n");
		}
	?>
	return guardTowerBorders;
}

function getGuardTowers() {
	var guardTower = [];
	<?php
		$gts = getAllGuardTowers();
		foreach ($gts as $gt) {
			echo("\tguardTower.push(L.marker(xy(".($gt[1][0] + 0.5).",".($gt[1][1] + 0.5).
			"),{icon: guardTowerIcon}).bindPopup(\"<div align='center'><b>Guard Tower</b><br><i>Created by ".$gt[1][3]."</i></div><br><b>QL:</b> ".(round($gt[1][4], 2))."<br><b>DMG:</b> ".(round($gt[1][5], 2))."\"));\n");
		}
	?>
	return guardTower;
}
<?php
	require 'config.php';

	function sendCommand($cmd) {
		$lines = file('http://'.$GLOBALS['RMI_ADDRESS'].'/'.$cmd);
		foreach ($lines as &$line) {
			$line = trim($line);
		}
		if (isset($lines[0]) && $lines[0] == "") {
			return array();
		}
		return $lines;
	}

	function parseArray($array, $explode = true, $nameKey = false) {
		if ($explode) {
			foreach ($array as $k => $v) {
				if ($v == "") {
					unset($array[$k]);
					continue;
				}
				$tmp = explode("=", $v);
				if ($nameKey) {
                			$new[$tmp[0]] = $tmp[1];
            			} else {
                			$array[$k] = array($tmp[0], $tmp[1]);;
            			}
        		}
        		if ($nameKey) {
            			return $new;
        		}
    		}
    		return $array;
	}

	function get_string_between($string, $start, $end) {
		$string = ' ' . $string;
		$ini = strpos($string, $start);
		if ($ini == 0) return '';
		$ini += strlen($start);
		$len = strpos($string, $end, $ini) - $ini;
		return substr($string, $ini, $len);
	}

	function getAllStructures() {
		$structures = parseArray(sendCommand("getAllStructures"));
		foreach ($structures as &$structure) {
			$structure[1] = parseArray(sendCommand("getStructureSummary?" . $structure[0]), true, true);
		}
		return $structures;
	}
?>
function getStructures() {
	var structureBorders = [];
	<?php
		$structures = getAllStructures();
		foreach ($structures as $structure) {
		echo("\tstructureBorders.push(L.polygon([xy(".$structure[1]['MinX'].",".$structure[1]['MinY']."),xy(".($structure[1]['MaxX']+1).",".$structure[1]['MinY']."),xy(".($structure[1]['MaxX']+1).",".($structure[1]['MaxY']+1)."),xy(".$structure[1]['MinX'].",".($structure[1]['MaxY']+1).")], {color:'blue',fillOpacity:0,weight:1}).bindPopup(\"".$structure[1]['Name']."\"));\n");
		}
	?>
	return structureBorders;
}
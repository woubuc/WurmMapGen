function getPlayerMarkers() {
	var playerMarkers = [];
	return playerMarkers;
}